import pandas as pd
from sqlalchemy import create_engine
from config import connection_string


def transform_to_clean():

    engine = create_engine(connection_string)

    query = "SELECT * FROM raw_currency_rates"

    raw_df = pd.read_sql(query, engine)

    raw_df["nominal"] = raw_df["nominal"].astype(int)
    raw_df["rate"] = raw_df["rate"].astype(float)
    raw_df["diff"] = raw_df["diff"].astype(float)
    raw_df["date"] = pd.to_datetime(raw_df["date"])

    clean_df = raw_df.copy()

    clean_df["currency_code"] = clean_df["ccy"]
    clean_df["currency_name"] = clean_df["ccy_nm_en"]
    clean_df["rate_uzs"] = clean_df["rate"]
    clean_df["diff_uzs"] = clean_df["diff"]
    clean_df["rate_date"] = clean_df["date"]

    clean_df["rate_per_unit"] = (
        clean_df["rate"] / clean_df["nominal"]
    )

    clean_df["change_direction"] = clean_df["diff_uzs"].apply(
        lambda x: "Increased"
        if x > 0
        else ("Decreased" if x < 0 else "No Change")
    )

    clean_df["is_appreciated"] = clean_df["diff_uzs"].apply(
        lambda x: 1 if x > 0 else 0
    )

    clean_df["is_depreciated"] = clean_df["diff_uzs"].apply(
        lambda x: 1 if x < 0 else 0
    )

    clean_to_load = clean_df[
        [
            "currency_code",
            "currency_name",
            "nominal",
            "rate_uzs",
            "diff_uzs",
            "rate_date",
            "loaded_at",
            "rate_per_unit",
            "change_direction",
            "is_appreciated",
            "is_depreciated"
        ]
    ]

    clean_to_load.to_sql(
        "clean_currency_rates",
        con=engine,
        if_exists="append",
        index=False
    )

    print("CLEAN data loaded successfully")


if __name__ == "__main__":
    transform_to_clean()