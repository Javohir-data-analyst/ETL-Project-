from extract_to_raw import extract_to_raw
from transform_to_clean import transform_to_clean
import logging
import os
from datetime import datetime

# Log fayl sozlash
log_dir = r"C:\etl_logs"
os.makedirs(log_dir, exist_ok=True)

logging.basicConfig(
    filename=os.path.join(log_dir, f"pipeline_{datetime.now().strftime('%Y%m%d')}.log"),
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

def run_pipeline():
    logging.info("Pipeline boshlandi...")
    
    try:
        extract_to_raw()
        logging.info("Extract tugadi ✅")
        
        transform_to_clean()
        logging.info("Transform tugadi ✅")
        
        print("Pipeline completed")
        logging.info("Pipeline muvaffaqiyatli tugadi!")
        
    except Exception as e:
        logging.error(f"Xato: {e}")
        print(f"Xato: {e}")

if __name__ == "__main__":
    run_pipeline()