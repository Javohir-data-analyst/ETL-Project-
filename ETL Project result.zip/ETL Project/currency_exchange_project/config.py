server="WIN-66OT1HGBVPF"
database="Project_3Task"
driver = "ODBC Driver 17 for SQL Server"

connection_string = f"mssql+pyodbc://@{server}/{database}?driver={driver}&trusted_connection=yes&charset=utf8"