create database Project_3Task
use Project_3Task

CREATE TABLE raw_currency_rates (
    raw_id INT IDENTITY(1,1) PRIMARY KEY,
    ccy NVARCHAR(10),
    ccy_nm_uz NVARCHAR(100),
    ccy_nm_ru NVARCHAR(100),
    ccy_nm_en NVARCHAR(100),
    nominal INT,
    rate FLOAT,
    diff FLOAT,
    date DATE,
    loaded_at DATETIME,
    source_system NVARCHAR(50),
    raw_json NVARCHAR(MAX)
);
CREATE TABLE clean_currency_rates (
    clean_id INT IDENTITY(1,1) PRIMARY KEY,
    currency_code NVARCHAR(10),
    currency_name NVARCHAR(100),
    nominal INT,
    rate_uzs FLOAT,
    diff_uzs FLOAT,
    rate_date DATE,
    loaded_at DATETIME,
    rate_per_unit FLOAT,
    change_direction NVARCHAR(20),
    is_appreciated INT,
    is_depreciated INT
);

select * from clean_currency_rates
