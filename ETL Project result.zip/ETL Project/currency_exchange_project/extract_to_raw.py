import requests
import pandas as pd
import json
from sqlalchemy import create_engine
from config import connection_string

def extract_to_raw():
    url = "https://cbu.uz/uz/arkhiv-kursov-valyut/json/"
    response = requests.get(url)
    data = response.json()

    #Bu yerda kelayotgan columnning ham qiymatini string type da o'qiydiga qildik
    raw_df = pd.DataFrame(data, dtype=str)
    print(raw_df)


    raw_df["raw_json"] = raw_df.apply(
            lambda row: json.dumps(row.to_dict(), ensure_ascii=False),
            axis=1
        )

    raw_df['loaded_at']=pd.Timestamp.now()
    raw_df['source_system'] = 'CBU_JSON'

    # Bu yerda columnlarni namelarini kichik harflarga o'girib oldikk
    raw_df = raw_df.rename(columns={
        "Ccy": "ccy",
        "CcyNm_RU": "ccy_nm_ru",
        "CcyNm_UZ": "ccy_nm_uz",
        "CcyNm_EN": "ccy_nm_en",
        "Nominal": "nominal",
        "Rate": "rate",
        "Diff": "diff",
        "Date": "date"
    })


    # Bu yerda bazi columnlarni type ni o'zgartirdik
    raw_df['nominal']=raw_df["nominal"].astype(int)
    raw_df['rate']=raw_df["rate"].astype(float)
    raw_df['diff']=raw_df["diff"].astype(float)
    raw_df['date'] = pd.to_datetime(
        raw_df["date"],
        format="%d.%m.%Y"
    )

    raw_df_to_other = raw_df[
        [
            "ccy",
            "ccy_nm_ru",
            "ccy_nm_uz",
            "ccy_nm_en",
            "nominal",
            "rate",
            "diff",
            "date",
            "loaded_at",
            "source_system",
            "raw_json"
        ]
    ]


    # Stringlarni unicode qilish;
    raw_df_to_other["ccy_nm_ru"] = raw_df_to_other["ccy_nm_ru"].astype(str)
    raw_df_to_other["ccy_nm_uz"] = raw_df_to_other["ccy_nm_uz"].astype(str)
    raw_df_to_other["ccy_nm_en"] = raw_df_to_other["ccy_nm_en"].astype(str)

    engine = create_engine(connection_string)

    raw_df_to_other.to_sql(
        "raw_currency_rates",
        con=engine,
        if_exists="append",
        index=False
    )

    print("Successfully")


if __name__ == "__main__":
    extract_to_raw()