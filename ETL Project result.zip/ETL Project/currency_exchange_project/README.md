# Currency Exchange ETL Pipeline

## Loyiha maqsadi
O'zbekiston Markaziy Banki (CBU) saytidan valyuta 
kurslarini avtomatik olib, SQL Server da saqlash, 
Python bilan tozalash va Power BI da vizualizatsiya 
qilish uchun yaratilgan ETL pipeline.

## Ishlatilgan texnologiyalar
- Python 3.13
- pandas
- requests
- SQLAlchemy + pyodbc
- SQL Server
- Power BI Desktop
- Windows Task Scheduler

## Pipeline qanday ishlaydi

1. `extract_to_raw.py` — CBU JSON API dan ma'lumot 
   oladi va raw_currency_rates jadvaliga yuklaydi
2. `transform_to_clean.py` — Raw jadvaldan o'qib, 
   tozalaydi va clean_currency_rates ga yozadi
3. `run_pipeline.py` — Ikkalasini ketma-ket ishga 
   tushiradi va log yozadi

## Ishga tushirish

pip install -r requirements.txt
python run_pipeline.py

## Avtomatlashtirish
Task Scheduler orqali har kuni soat 09:00 da 
run_pipeline.py avtomatik ishga tushadi.

## Loyiha strukturasi
currency_exchange_project/
├── config.py
├── extract_to_raw.py
├── transform_to_clean.py
├── run_pipeline.py
├── requirements.txt
└── README.md